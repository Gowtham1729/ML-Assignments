import numpy as np
import matplotlib.pyplot as plt

a = np.array([[0.4**3, 0.4**4, 0.4**5, 0.4**6, 0.4**7], [3*(0.4**2), 4*(0.4**3), 5*(0.4**4), 6*(0.4**5), 7*(0.4**6)], [1,1,1,1,1], [3,4,5,6,7], [6,12,20,30,42]])  

b = np.array([50,0,0,0,0]) 
x = np.linalg.solve(a, b)
print(x)

c3 = x[0]
c4 = x[1]
c5 = x[2]
c6 = x[3]
c7 = x[4]
t = np.linspace(0, 150, 300)
b = 150

s = (c3*((t/b)**3)) + (c4 * ((t/b)**4)) + (c5*((t/b)**5)) + (c6*((t/b)**6)) + (c7*((t/b)**7))
v = ( (3*c3*(t/b)**2) + (4*c4*(t/b)**3) + (5*c5*(t/b)**4) + (6*c6*(t/b)**5) + (7*c7*(t/b)**6)) /b
a = ( (6*c3*(t/b)) + (12*c4*(t/b)**2) + (20*c5*(t/b)**3) + (30*c6*(t/b)**4) + (42*c7*(t/b)**5))/b**2 
j = ( (6*c3) + (24*c4*(t/b)**1) + (60*c5*(t/b)**2) + (120*c6*(t/b)**3) + (210*c7*(t/b)**4))/b**3

plt.figure(figsize=(20,8))
plt.plot(t, s)
plt.show()

plt.figure()
plt.plot(t, v)
plt.show()

plt.figure()
plt.plot(t, a)
plt.show()

plt.figure()
plt.plot(t, j)
plt.show()
